module.exports = {
  mongoURI: 'mongodb+srv://lucaswgong:hihumi2301@cluster0.3kx5a.mongodb.net/quizDB?retryWrites=true&w=majority'
}
